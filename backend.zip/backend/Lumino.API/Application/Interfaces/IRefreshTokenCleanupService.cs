namespace Lumino.Api.Application.Interfaces
{
    public interface IRefreshTokenCleanupService
    {
        int Cleanup();
    }
}
