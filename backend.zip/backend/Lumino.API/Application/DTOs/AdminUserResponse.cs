namespace Lumino.Api.Application.DTOs
{
    public class AdminUserResponse : UserProfileResponse
    {
    }
}
