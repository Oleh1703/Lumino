namespace Lumino.Api.Application.DTOs
{
    public class MarkSceneCompletedRequest
    {
        public int SceneId { get; set; }
    }
}
