namespace Lumino.Api.Application.DTOs
{
    public class ReviewVocabularyRequest
    {
        public bool IsCorrect { get; set; }
    }
}
