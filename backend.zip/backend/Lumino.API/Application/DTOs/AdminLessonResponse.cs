namespace Lumino.Api.Application.DTOs
{
    public class AdminLessonResponse : LessonResponse
    {
    }
}
