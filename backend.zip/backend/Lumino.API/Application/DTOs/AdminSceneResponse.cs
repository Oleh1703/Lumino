namespace Lumino.Api.Application.DTOs
{
    public class AdminSceneResponse : SceneResponse
    {
    }
}
