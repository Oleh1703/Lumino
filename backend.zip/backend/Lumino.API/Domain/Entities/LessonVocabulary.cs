namespace Lumino.Api.Domain.Entities
{
    public class LessonVocabulary
    {
        public int Id { get; set; }

        public int LessonId { get; set; }

        public int VocabularyItemId { get; set; }
    }
}
