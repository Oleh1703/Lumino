namespace Lumino.Api.Domain.Entities
{
    public class ExerciseVocabulary
    {
        public int Id { get; set; }

        public int ExerciseId { get; set; }

        public int VocabularyItemId { get; set; }
    }
}
