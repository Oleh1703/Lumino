﻿namespace Lumino.Api.Domain.Enums
{
    public enum ExerciseType
    {
        MultipleChoice = 1,
        Input = 2,
        Match = 3
    }
}
