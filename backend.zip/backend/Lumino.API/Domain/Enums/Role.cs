﻿namespace Lumino.Api.Domain.Enums
{
    public enum Role
    {
        User = 1,
        Admin = 2
    }
}
