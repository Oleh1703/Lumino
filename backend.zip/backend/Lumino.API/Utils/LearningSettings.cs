using System.Collections.Generic;

namespace Lumino.Api.Utils
{
    public class LearningSettings
    {
        public int PassingScorePercent { get; set; } = 80;

        public int SceneCompletionScore { get; set; } = 5;

        // скільки пройдених уроків потрібно на відкриття кожної наступної сцени.
        // правило: requiredLessons = (sceneId - 1) * SceneUnlockEveryLessons
        public int SceneUnlockEveryLessons { get; set; } = 1;

        // SRS (Vocabulary): через скільки годин повторюємо слово після помилки.
        public int VocabularyWrongDelayHours { get; set; } = 12;

        // SRS (Vocabulary): інтервали повторення в днях для правильних відповідей.
        // приклад: 1, 2, 4, 7, 14, 30, 60...
        public List<int> VocabularyReviewIntervalsDays { get; set; } = new List<int> { 1, 2, 4, 7, 14, 30, 60 };
    }
}
