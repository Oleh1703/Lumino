﻿using Lumino.Api.Application.DTOs;
using Lumino.Api.Application.Services;
using Lumino.Api.Application.Validators;
using Lumino.Api.Domain.Entities;
using Lumino.Api.Domain.Enums;
using Lumino.Api.Utils;
using Microsoft.Extensions.Options;
using System.Text.Json;
using Xunit;

namespace Lumino.Tests.Integration;

public class LessonResultServiceIntegrationTests
{
    [Fact]
    public void SubmitLesson_LockedLesson_ShouldThrow()
    {
        var dbContext = TestDbContextFactory.Create();

        dbContext.Lessons.Add(new Lesson
        {
            Id = 1,
            Title = "Lesson 1",
            Theory = "Text",
            TopicId = 1,
            Order = 1
        });

        dbContext.Exercises.Add(new Exercise
        {
            Id = 1,
            LessonId = 1,
            Type = ExerciseType.Input,
            Question = "Q1",
            Data = "",
            CorrectAnswer = "hello",
            Order = 1
        });

        dbContext.SaveChanges();

        var service = new LessonResultService(
            dbContext,
            new FakeAchievementService(),
            new FakeDateTimeProvider(),
            new SubmitLessonRequestValidator(),
            Options.Create(new LearningSettings { PassingScorePercent = 80 })
        );

        Assert.Throws<ForbiddenAccessException>(() =>
        {
            service.SubmitLesson(10, new SubmitLessonRequest
            {
                LessonId = 1,
                Answers = new List<SubmitExerciseAnswerRequest>
                {
                    new SubmitExerciseAnswerRequest { ExerciseId = 1, Answer = "hello" }
                }
            });
        });
    }

    [Fact]
    public void SubmitLesson_ShouldCreateLessonResult_AndUpdateProgress()
    {
        var dbContext = TestDbContextFactory.Create();

        dbContext.Lessons.Add(new Lesson
        {
            Id = 1,
            Title = "Lesson 1",
            Theory = "Text",
            TopicId = 1,
            Order = 1
        });

        dbContext.Exercises.Add(new Exercise
        {
            Id = 1,
            LessonId = 1,
            Type = ExerciseType.Input,
            Question = "Q1",
            Data = "",
            CorrectAnswer = "hello",
            Order = 1
        });

        dbContext.Exercises.Add(new Exercise
        {
            Id = 2,
            LessonId = 1,
            Type = ExerciseType.Input,
            Question = "Q2",
            Data = "",
            CorrectAnswer = "world",
            Order = 2
        });

        dbContext.UserLessonProgresses.Add(new UserLessonProgress
        {
            UserId = 10,
            LessonId = 1,
            IsUnlocked = true,
            IsCompleted = false,
            BestScore = 0,
            LastAttemptAt = DateTime.UtcNow
        });

        dbContext.SaveChanges();

        var service = new LessonResultService(
            dbContext,
            new FakeAchievementService(),
            new FakeDateTimeProvider(),
            new SubmitLessonRequestValidator(),
            Options.Create(new LearningSettings { PassingScorePercent = 80 })
        );

        var response = service.SubmitLesson(10, new SubmitLessonRequest
        {
            LessonId = 1,
            Answers = new List<SubmitExerciseAnswerRequest>
            {
                new SubmitExerciseAnswerRequest { ExerciseId = 1, Answer = "hello" },
                new SubmitExerciseAnswerRequest { ExerciseId = 2, Answer = "world" }
            }
        });

        Assert.Equal(2, response.TotalExercises);
        Assert.Equal(2, response.CorrectAnswers);
        Assert.True(response.IsPassed);

        Assert.Equal(1, dbContext.LessonResults.Count(x => x.UserId == 10 && x.LessonId == 1));

        var progress = dbContext.UserProgresses.FirstOrDefault(x => x.UserId == 10);
        Assert.NotNull(progress);
        Assert.True(progress!.CompletedLessons >= 1);
        Assert.True(progress.TotalScore >= 2);
    }

    [Fact]
    public void SubmitLesson_MatchExercise_ShouldEvaluateCorrectly()
    {
        var dbContext = TestDbContextFactory.Create();

        dbContext.Lessons.Add(new Lesson
        {
            Id = 1,
            Title = "Lesson Match",
            Theory = "Text",
            TopicId = 1,
            Order = 1
        });

        var correctPairs = new[]
        {
            new { left = "Hello", right = "Привіт" },
            new { left = "Goodbye", right = "До побачення" }
        };

        var userPairs = new[]
        {
            new { left = "Goodbye", right = "До побачення" },
            new { left = "Hello", right = "Привіт" }
        };

        dbContext.Exercises.Add(new Exercise
        {
            Id = 1,
            LessonId = 1,
            Type = ExerciseType.Match,
            Question = "Match the pairs",
            Data = JsonSerializer.Serialize(correctPairs),
            CorrectAnswer = "{}",
            Order = 1
        });

        dbContext.UserLessonProgresses.Add(new UserLessonProgress
        {
            UserId = 10,
            LessonId = 1,
            IsUnlocked = true,
            IsCompleted = false,
            BestScore = 0,
            LastAttemptAt = DateTime.UtcNow
        });

        dbContext.SaveChanges();

        var service = new LessonResultService(
            dbContext,
            new FakeAchievementService(),
            new FakeDateTimeProvider(),
            new SubmitLessonRequestValidator(),
            Options.Create(new LearningSettings { PassingScorePercent = 80 })
        );

        var response = service.SubmitLesson(10, new SubmitLessonRequest
        {
            LessonId = 1,
            Answers = new List<SubmitExerciseAnswerRequest>
            {
                new SubmitExerciseAnswerRequest
                {
                    ExerciseId = 1,
                    Answer = JsonSerializer.Serialize(userPairs)
                }
            }
        });

        Assert.Equal(1, response.TotalExercises);
        Assert.Equal(1, response.CorrectAnswers);
        Assert.True(response.IsPassed);
        Assert.Single(response.Answers);
        Assert.True(response.Answers[0].IsCorrect);
    }

    [Fact]
    public void SubmitLesson_EmptyAnswers_ShouldThrow()
    {
        var dbContext = TestDbContextFactory.Create();

        var service = new LessonResultService(
            dbContext,
            new FakeAchievementService(),
            new FakeDateTimeProvider(),
            new SubmitLessonRequestValidator(),
            Options.Create(new LearningSettings { PassingScorePercent = 80 })
        );

        Assert.Throws<ArgumentException>(() =>
        {
            service.SubmitLesson(10, new SubmitLessonRequest
            {
                LessonId = 1,
                Answers = new List<SubmitExerciseAnswerRequest>()
            });
        });
    }

    // lesson not found
    [Fact]
    public void SubmitLesson_LessonNotFound_ShouldThrow()
    {
        var dbContext = TestDbContextFactory.Create();

        var service = new LessonResultService(
            dbContext,
            new FakeAchievementService(),
            new FakeDateTimeProvider(),
            new SubmitLessonRequestValidator(),
            Options.Create(new LearningSettings { PassingScorePercent = 80 })
        );

        Assert.Throws<KeyNotFoundException>(() =>
        {
            service.SubmitLesson(10, new SubmitLessonRequest
            {
                LessonId = 999,
                Answers = new List<SubmitExerciseAnswerRequest>
                {
                    new SubmitExerciseAnswerRequest { ExerciseId = 1, Answer = "hello" }
                }
            });
        });
    }

    // partial correct -> IsPassed false (80%)
    [Fact]
    public void SubmitLesson_PartialCorrect_ShouldNotPass()
    {
        var dbContext = TestDbContextFactory.Create();

        dbContext.Lessons.Add(new Lesson
        {
            Id = 1,
            Title = "Lesson 1",
            Theory = "Text",
            TopicId = 1,
            Order = 1
        });

        dbContext.Exercises.Add(new Exercise
        {
            Id = 1,
            LessonId = 1,
            Type = ExerciseType.Input,
            Question = "Q1",
            Data = "",
            CorrectAnswer = "hello",
            Order = 1
        });

        dbContext.Exercises.Add(new Exercise
        {
            Id = 2,
            LessonId = 1,
            Type = ExerciseType.Input,
            Question = "Q2",
            Data = "",
            CorrectAnswer = "world",
            Order = 2
        });

        dbContext.UserLessonProgresses.Add(new UserLessonProgress
        {
            UserId = 10,
            LessonId = 1,
            IsUnlocked = true,
            IsCompleted = false,
            BestScore = 0,
            LastAttemptAt = DateTime.UtcNow
        });

        dbContext.SaveChanges();

        var service = new LessonResultService(
            dbContext,
            new FakeAchievementService(),
            new FakeDateTimeProvider(),
            new SubmitLessonRequestValidator(),
            Options.Create(new LearningSettings { PassingScorePercent = 80 })
        );

        var response = service.SubmitLesson(10, new SubmitLessonRequest
        {
            LessonId = 1,
            Answers = new List<SubmitExerciseAnswerRequest>
            {
                new SubmitExerciseAnswerRequest { ExerciseId = 1, Answer = "hello" },
                new SubmitExerciseAnswerRequest { ExerciseId = 2, Answer = "WRONG" }
            }
        });

        Assert.Equal(2, response.TotalExercises);
        Assert.Equal(1, response.CorrectAnswers);
        Assert.False(response.IsPassed);
    }

    // call twice -> TotalScore must not be farmed
    [Fact]
    public void SubmitLesson_Twice_ShouldNotFarmTotalScore()
    {
        var dbContext = TestDbContextFactory.Create();

        dbContext.Lessons.Add(new Lesson
        {
            Id = 1,
            Title = "Lesson 1",
            Theory = "Text",
            TopicId = 1,
            Order = 1
        });

        dbContext.Exercises.Add(new Exercise
        {
            Id = 1,
            LessonId = 1,
            Type = ExerciseType.Input,
            Question = "Q1",
            Data = "",
            CorrectAnswer = "hello",
            Order = 1
        });

        dbContext.UserLessonProgresses.Add(new UserLessonProgress
        {
            UserId = 10,
            LessonId = 1,
            IsUnlocked = true,
            IsCompleted = false,
            BestScore = 0,
            LastAttemptAt = DateTime.UtcNow
        });

        dbContext.SaveChanges();

        var service = new LessonResultService(
            dbContext,
            new FakeAchievementService(),
            new FakeDateTimeProvider(),
            new SubmitLessonRequestValidator(),
            Options.Create(new LearningSettings { PassingScorePercent = 80 })
        );

        var userId = 10;

        service.SubmitLesson(userId, new SubmitLessonRequest
        {
            LessonId = 1,
            Answers = new List<SubmitExerciseAnswerRequest>
            {
                new SubmitExerciseAnswerRequest { ExerciseId = 1, Answer = "hello" }
            }
        });

        service.SubmitLesson(userId, new SubmitLessonRequest
        {
            LessonId = 1,
            Answers = new List<SubmitExerciseAnswerRequest>
            {
                new SubmitExerciseAnswerRequest { ExerciseId = 1, Answer = "hello" }
            }
        });

        Assert.Equal(2, dbContext.LessonResults.Count(x => x.UserId == userId && x.LessonId == 1));

        var progress = dbContext.UserProgresses.FirstOrDefault(x => x.UserId == userId);
        Assert.NotNull(progress);

        Assert.Equal(1, progress!.CompletedLessons);

        // TotalScore = best score per lesson, тому 1, а не 2
        Assert.Equal(1, progress.TotalScore);
    }
}
